<?php 
    include 'koneksi.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1> Edit Data Barang </h1>
<?php 
    $id = $_GET['id'];
    $query =" SELECT * FROM kendaraan WHERE id_kendaraan= '$id'";
    $sql = mysqli_query($koneksi, $query);
    $data = mysqli_fetch_assoc($sql);
?>
<form method="POST">
    <label > Nama Kendaraan : </label>
    <input type="text" name="nama_kendaraan" id= "" value="<?php echo $data['nama_kendaraan']; ?>"><br>
    <label > Jenis Kendaraan : </label>
    <input type="text" name="jenis_kendaraan" id= "" value="<?php echo $data['jenis_kendaraan']; ?>"><br>
    <label > Harga Kendaraan : </label>
    <input type="text" name="harga_kendaraan" id= "" value="<?php echo $data['harga_kendaraan']; ?>"><br>
    <label > Stok Kendaraan : </label>
    <input type="text" name="stok_kendaraan" id= "" value="<?php echo $data['stok_kendaraan']; ?>"><br>

    <button type="submit" name="btn_update">Edit</button>
</form>
<?php
if (isset ($_POST['btn_update'])){
    $nama_kendaraan = $_POST['nama_kendaraan'];
    $jenis_kendaraan = $_POST['jenis_kendaraan'];
    $harga_kendaraan = $_POST['harga_kendaraan'];
    $stok_kendaraan = $_POST['stok_kendaraan'];

    $sql = "UPDATE kendaraan SET nama_kendaraan = '$nama_kendaraan', jenis_kendaraan='$jenis_kendaraan', harga_kendaraan='$harga_kendaraan', stok_kendaraan='$stok_kendaraan' WHERE id_kendaraan='$id'";
    mysqli_query($koneksi, $sql);
    header('location: index.php');
}
?>
</body>
</html>