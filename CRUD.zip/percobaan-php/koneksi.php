<?php 
    $server = 'localhost';
    $username = 'root';
    $password = '';
    $database = 'percobaan';

    $koneksi = mysqli_connect($server, $username, $password,  $database);
?>