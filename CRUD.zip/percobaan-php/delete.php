<?php 
   include 'koneksi.php';
   $id = $_GET['id'];
    $query = "DELETE FROM kendaraan WHERE id_kendaraan='$id'";
    mysqli_query($koneksi, $query);
    header('location:index.php');
?>