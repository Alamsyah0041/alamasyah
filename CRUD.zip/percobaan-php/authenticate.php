<?php
session_start();

// Ganti dengan data koneksi Anda
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "percobaan";

// Membuat koneksi
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_POST['username'];
$password = md5($_POST['password']); // Menggunakan MD5 untuk enkripsi sederhana (tidak disarankan untuk produksi)

$sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $_SESSION['username'] = $username;
    // Redirect ke halaman yang diinginkan setelah login berhasil
    header("Location: index.php");
} else {
    echo "Username atau password salah";
}
$conn->close();
?>
