<?php 
    include 'koneksi.php';
?>

<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Percobaaan</title>
    <style>
        .merah{
            color:red;
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <h1 class="merah" align = "center"> Kendaraan </h1>
    <div style="text-align: right; margin-right: 20px;">
        <a href="logout.php"  class="  btn btn-success " > log out </a>
    </div>
    <center>
        <a href ="create.php " class="btn btn-primary" align = "center" > Tambah Data </a>
    </center> <br>
        <table class="table table-dark table-hover" border="1" align='center' width='60%' cellpadding='10' cellspacing='0'> 
        
            <tr>
                <th>No </th>
                <th>Nama Kendaraan</th>
                <th>Jenis Kendaraan</th>
                <th>Harga Kendaraan</th>
                <th>Stok Kendaraan</th>
                <th>Aksi</th>
            </tr>
            <?php
                 $i=1;

                 $query = 'SELECT * FROM kendaraan ';
                 $sql = mysqli_query($koneksi, $query);
                 while ($data = mysqli_fetch_assoc($sql)){

            ?>
            <tr>
                <td> <?php echo $i++ ?> </td>
                <td> <?php echo $data['nama_kendaraan']?> </td>
                <td> <?php echo $data['jenis_kendaraan']?>  </td>
                <td> <?php echo $data['harga_kendaraan']?> </td>
                <td> <?php echo $data['stok_kendaraan']?> </td>
            
                <td>
                    <a href="update.php?id=<?php echo $data['id_kendaraan']; ?>" class="btn btn-warning"> Edit </a> |
                    <a href="delete.php?id=<?php echo $data['id_kendaraan']; ?>" class="btn btn-danger" >Hapus</a>
                </td>
            </tr>
                 <?php   } ?>       
        </table>

        
    
</body>
</html>



