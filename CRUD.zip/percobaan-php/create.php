<?php 
    include 'koneksi.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<h1> Tambahkan Data </h1>
    <form method="POST">
        <!-- <label >Nama Kendaraan :</label>
        <input type="text" name="nama_kendaraan" id=""><br> -->
        <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Nama Kendaraan</label>
    <input type="text" name="nama_kendaraan" class="form-control" id="exampleInputEmail1" >
  </div>

        <!-- <label >Jenis Kendaraan :</label>
        <input type="text" name="jenis_kendaraan" id=""><br> -->
        <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Jenis Kendaraan</label>
    <input type="text" name="jenis_kendaraan" class="form-control" id="exampleInputEmail1" >
  </div>

        <!-- <label >Harga Kendaraan :</label>
        <input type="text" name="harga_kendaraan" id=""><br> -->
        <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Harga Kendaraan</label>
    <input type="text" name="harga_kendaraan" class="form-control" id="exampleInputEmail1" >
  </div>

        <!-- <label >Stok Kendaraan:</label>
        <input type="text" name="stok_kendaraan" id=""><br>
         -->
         <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">stok Kendaraan</label>
    <input type="text" name="stok_kendaraan" class="form-control" id="exampleInputEmail1" >
  </div>
        <button type="submit" name="btn_create">Tambahkan </button>
    </form>

    <?php 
    
        if(isset ($_POST['btn_create'])){
            $nama_kendaraan = $_POST['nama_kendaraan'];
            $jenis_kendaraan = $_POST['jenis_kendaraan'];
            $harga_kendaraan = $_POST['harga_kendaraan'];
            $stok_kendaraan = $_POST['stok_kendaraan'];

            mysqli_query($koneksi, "INSERT INTO kendaraan(nama_kendaraan, jenis_kendaraan, harga_kendaraan, stok_kendaraan) VALUES('$nama_kendaraan', '$jenis_kendaraan', '$harga_kendaraan', '$stok_kendaraan' )");
    //header fungsinya klo disumbit langsung kembali index.php
            header('location:index.php');
        } 
        ?>
</body>
</html>